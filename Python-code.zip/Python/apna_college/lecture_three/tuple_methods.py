#TUPLE METHODS
tup = (2,4,3,1,6,1,3,3,6)
print(tup.index(1))     #returns the index of first occurrence of element 1 which is 3

print("elemt 2 is occurring ",tup.count(2), " times in tuple")    #counts total occurrences of elemnt 2 
print("elemt 2 is occurring ", tup.count(3), " times in tuple")    

