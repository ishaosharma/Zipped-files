# print("Hello Isha")
# print("Hello Sharma") 

# print("Hello Isha", "Hello Sharma")

# variables
# name = "Isha"
# age = 23
# price = 87.66
# old = False
# a = None
# print(type(old))
# print(type(a))

# print("name") 
# print("Name is = ", name)
# print("Age is = ", age)
# print("Price is = ", price)

# print(type(name))
# print(type(age))
# print(type(price))


# message= 'Hola amigos'
# print(message)
# message = 'Hello Isha sharma'
# print(message)


"""
This is a multiline comment
num1 = 30
num2 = 20
diff = num1-num2
print("diff is : ", diff)

"""

#inputs in python
naming = input("Enter your name :")
print("Welcome ", naming) 



