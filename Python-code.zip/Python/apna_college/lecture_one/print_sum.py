num1 = 30
num2 = 20
sum = num1+num2
print("sum is : ", sum)

num1 = 30
num2 = 20
diff = num1-num2
print("diff is : ", diff)


