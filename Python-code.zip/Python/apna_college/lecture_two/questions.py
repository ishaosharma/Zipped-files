#WAP TO INPUT USER'S FIRST NAME AND PRINT IT'S LENGTH
first_name = input("Enter your first name : ")
print("Your first name is ", first_name," and length is : ", len(first_name))

#WAP to find the ocurrence of $ in a string
str = "Hi! i am happy as i have $999.99 in my FD"
print(str.count("$"))