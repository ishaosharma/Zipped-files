#Indexing - Accessing of single element in string
name = "Isha Sharma"
print(name[0])
# name[0] = 'B'  NOT ALLOWED 