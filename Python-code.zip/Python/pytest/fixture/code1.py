def test_user_role(sample_data):
    assert sample_data["role"] == "Developer"