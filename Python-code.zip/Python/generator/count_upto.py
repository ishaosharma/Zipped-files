def count_up_to(n):
    count = 1
    while count < n:
        yield count
        count += 1

for value in count_up_to(12):
    print(value, end = " ")