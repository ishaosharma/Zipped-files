b = ([1,2])
print(type(b))

b1 = ([1,2],)
print(type(b1))

t1 = (10)
print(type(t1))


my_tuple = (1,2,3,['a'])
print(my_tuple[2])
my_tuple[3].append('b')
print(my_tuple)