# Q1. You're developing a Python program to handle string operations for managing user input. 
# Implement the following functionalities
# 1. Remove duplicate characters from a string while preserving the original order. 
# 2. Check if a string is a palindrome.
# 3. Count the occurrences of each character in a String and store them in a dictionary.
# 4. Reverse words in a sentence while maintaining the order of words.

word = input("Enter the word : ")
print(word)






































# find(4) is present or not - TRUE, FALSE
# find(10) - False
# find (2) - TRUE

# items = [1,2,3,4,5,6,7,8]
# n = int(input("Enter number : "))
# for item in items:
#     if n in items:
#         print("TRUE")
#         break
#     elif
#         print("FALSE")
# print("FALSE")


# fruits = ['apple', 'banana', 'apple', 'guava', 'mango', 'apple', 'banana']
# o/p:
# apple 3
# banana 2
# guava 1
# mango 1

# output = {}
# for item in fruits:
#     if item not in output:
#         output += item
# elif:
#         count = 1
    


 



